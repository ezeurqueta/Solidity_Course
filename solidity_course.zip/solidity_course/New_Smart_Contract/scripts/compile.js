const path = require('path');
const fs = require('fs');
const solc = require('solc');
const chalk = require('chalk');
 
 
const contractFileName = 'UsersContract.sol';
const contractName = 'UsersContract';
 
const contractPath = path.resolve(__dirname, "../contracts", contractFileName);
const source = fs.readFileSync(contractPath, 'utf8');
 
let input = {
    language: 'Solidity',
    sources: {
        [contractFileName]: {
            content: source,
        }
    },
    settings: {
        outputSelection: {
            '*': {
                '*': ['*']
            }
        }
    }
};
 
var output = JSON.parse(solc.compile(JSON.stringify(input))).contracts[contractFileName];
 
const { abi, evm} = output[contractName];
 
console.log(chalk.green(evm.bytecode.object));
console.log(chalk.cyan(abi));